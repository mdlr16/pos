const config = {
    API_URL: window.APP_CONFIG?.API_URL || process.env.REACT_APP_API_URL || 'https://default-url.com'
  };
  
  export default config;