import React, { useContext, useState, useEffect } from 'react';
import { AuthContext } from '../context/AuthContext';
import { Terminal, User, Building2 } from 'lucide-react';
import Pos from './Pos';

const Dashboard = () => {
  const { user, company, variables, userId, pwd } = useContext(AuthContext);
  const [terminals, setTerminals] = useState([]);
  const [selectedTerminal, setSelectedTerminal] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [initialBalance, setInitialBalance] = useState(0);
  const [cashAccount, setCashAccount] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const profileImage = `${variables.SPOS_URL}/documents/mycompany/logos/thumbs/${variables.MAIN_INFO_SOCIETE_LOGO_SQUARRED_MINI}`;
  const API_URL = process.env.REACT_APP_API_URL;

  useEffect(() => {
    const fetchTerminals = async () => {
      setIsLoading(true);
      try {
        const response = await fetch(`${API_URL}/login.php?login=${user}&password=${pwd}`);
        const data = await response.json();

        if (data.status === 'success') {
          setTerminals(data.terminals);
        } else {
          console.error("Error fetching terminals:", data.message);
        }
      } catch (error) {
        console.error("Error during fetch:", error);
      }
      setIsLoading(false);
    };

    if (user && pwd) {
      fetchTerminals();
    }
  }, [user, pwd, API_URL]);

  const handleTerminalChange = (e) => {
    const terminalId = e.target.value;
    const terminal = terminals.find(t => t.rowid === terminalId);
    
    if (terminal) {
      console.log('Terminal selected:', terminal);
      
      // Establecemos el terminal seleccionado
      setSelectedTerminal(terminal);

      // Si el terminal está cerrado, abrimos el modal directamente
      if (terminal.is_closed === "1") {
        console.log('Terminal is closed, opening modal');
        setIsModalOpen(true);
        
        // Si hay métodos de pago, buscamos el de efectivo
        if (terminal.payment_methods?.length > 0) {
          const efectivoAccount = terminal.payment_methods.find(
            method => method.label?.toUpperCase() === "EFECTIVO"
          );
          setCashAccount(efectivoAccount || null);
        }
      }
    }
  };

  const handleInitialBalanceSubmit = async () => {
    try {
      const response = await fetch(`${variables.SPOS_URL}/custom/pos/frontend/ajax_pos_siel.php?action=postSaldo`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          terminalId: selectedTerminal.rowid,
          cashAccountId: cashAccount?.fk_bank || '',
          initialBalance,
          user: userId
        }),
      });
      
      const data = await response.json();
      if (data.success) {
        console.log("Initial balance updated successfully");
        setIsModalOpen(false);
      } else {
        console.error("Error updating balance:", data.message);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  if (selectedTerminal && !isModalOpen) {
    return <Pos terminal={selectedTerminal} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header Section */}
          <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <img
                  src={profileImage}
                  alt="Company Logo"
                  className="w-16 h-16 object-contain rounded-lg"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = '/placeholder-logo.png';
                  }}
                />
                <div>
                  <h1 className="text-2xl font-bold text-gray-800">SIEL POS</h1>
                  <p className="text-gray-600">Panel de Control</p>
                </div>
              </div>
            </div>

            {/* User Info Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <div className="bg-blue-50 rounded-lg p-4 flex items-center space-x-3">
                <User className="w-6 h-6 text-blue-600" />
                <div>
                  <p className="text-sm text-gray-600">Usuario</p>
                  <p className="font-semibold text-gray-800">{user}</p>
                </div>
              </div>
              
              <div className="bg-indigo-50 rounded-lg p-4 flex items-center space-x-3">
                <Building2 className="w-6 h-6 text-indigo-600" />
                <div>
                  <p className="text-sm text-gray-600">Empresa</p>
                  <p className="font-semibold text-gray-800">{variables.MAIN_INFO_SOCIETE_NOM}</p>
                </div>
              </div>
            </div>

            {/* Terminal Selection */}
            <div className="bg-gray-50 rounded-lg p-6">
              <label className="block text-gray-700 font-semibold mb-3">
                Seleccione una terminal:
              </label>
              <select
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                onChange={handleTerminalChange}
                defaultValue=""
                disabled={isLoading}
              >
                <option disabled value="">
                  {isLoading ? "Cargando terminales..." : "Seleccione una terminal"}
                </option>
                {terminals.map((terminal) => (
                  <option key={terminal.rowid} value={terminal.rowid}>
                    {terminal.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Modal for Initial Balance */}
      {isModalOpen && selectedTerminal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">
              Saldo inicial para {selectedTerminal?.name}
            </h2>
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ingrese el saldo inicial
              </label>
              <input
                type="number"
                value={initialBalance}
                onChange={(e) => setInitialBalance(Number(e.target.value))}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="0.00"
              />
            </div>
            <div className="flex space-x-3">
              <button
                onClick={handleInitialBalanceSubmit}
                className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Guardar
              </button>
              <button
                onClick={() => {
                  setIsModalOpen(false);
                  setSelectedTerminal(null);
                }}
                className="flex-1 bg-gray-200 text-gray-800 py-2 px-4 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;