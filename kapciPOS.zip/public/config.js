window.APP_CONFIG = {
    API_URL: "https://kapci2.sielerp.com/custom/pos/pos_siel"  // cambiar
  };