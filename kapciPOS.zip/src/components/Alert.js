import React, { useEffect } from 'react';

const Alert = ({ message, type, onClose }) => {
  const alertStyles = {
    success: 'bg-green-100 text-green-700 border-green-500',
    error: 'bg-red-100 text-red-700 border-red-500',
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 5000);

    // Limpiar el temporizador si el componente se desmonta antes de que pasen los 5 segundos
    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className={`fixed bottom-4 right-4 p-4 rounded-lg border ${alertStyles[type]} shadow-lg flex items-center`}>
      <div className="mr-4">
        <span>{message}</span>
      </div>
      <button className="text-xl font-bold" onClick={onClose}>
        &times;
      </button>
    </div>
  );
};

export default Alert;