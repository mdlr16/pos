import React from 'react';

const SplashScreen = () => {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-gradient-to-br from-teal-900 via-teal-800 to-cyan-600">
      <div className="relative p-8 rounded-2xl bg-white/10 backdrop-blur-sm shadow-2xl">
        <div className="absolute inset-0 bg-white/5 rounded-2xl animate-pulse" />
        
        {/* Contenedor principal */}
        <div className="relative z-10 text-center">
          {/* Logo con efecto de brillo */}
          <div className="relative mb-8 group">
            <div className="absolute inset-0 bg-cyan-400/20 filter blur-xl rounded-full animate-pulse group-hover:bg-cyan-400/30" />
            <img 
              src="siel.png" 
              alt="Grupo SIEL" 
              className="relative h-32 w-auto mx-auto object-contain drop-shadow-xl"
            />
          </div>
          
          {/* Spinner personalizado */}
          <div className="relative w-16 h-16 mx-auto mb-6">
            <div className="absolute inset-0 rounded-full border-4 border-white/20" />
            <div className="absolute inset-0 rounded-full border-4 border-cyan-400 border-t-transparent animate-spin" />
          </div>
          
          {/* Textos con mejor tipografía y efectos */}
          <h1 className="text-4xl font-bold text-white tracking-wider mb-2">
            Grupo SIEL
          </h1>
          <p className="text-cyan-100 text-lg font-light tracking-widest uppercase">
            Sistema de Punto de Venta
          </p>
          
          {/* Mensaje de carga */}
          <div className="mt-6 text-cyan-200/80 text-sm animate-pulse">
            Iniciando sistema...
          </div>
        </div>
      </div>
      
      {/* Elementos decorativos de fondo */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-teal-400/10 rounded-full animate-pulse" style={{ animationDelay: '0.5s' }} />
        <div className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-cyan-400/10 rounded-full animate-pulse" style={{ animationDelay: '1s' }} />
      </div>
    </div>
  );
};

export default SplashScreen;