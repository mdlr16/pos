import React, { createContext, useState, useEffect } from 'react';
import config from '../config';  // Importamos la configuración

export const AuthContext = createContext();

// Reemplazamos la constante API_URL con la configuración importada
const API_URL = config.API_URL;

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [company, setCompany] = useState(null);
  const [userId, setUserId] = useState(null);
  const [pwd, setPwd] = useState(null);
  const [variables, setVariables] = useState({});

  useEffect(() => {
    // Podemos añadir un log para verificar la URL que se está usando
    console.log('Using API URL:', API_URL);

    const storedUser = localStorage.getItem('user');
    const storedUserId = localStorage.getItem('userId');
    const storedCompany = localStorage.getItem('company');
    const storedPwd = localStorage.getItem('pwd');
    const storedVariables = JSON.parse(localStorage.getItem('variables'));
    if (storedUser && storedUserId && storedCompany && storedPwd) {
      setUser(storedUser);
      setUserId(storedUserId);
      setCompany(storedCompany);
      setPwd(storedPwd);
      setVariables(storedVariables || {});
    }
  }, []);

  const login = async (username, password) => {
    try {
      const response = await fetch(`${API_URL}/login.php?login=${username}&password=${password}`, {    
        method: 'GET',
      });
      const data = await response.json();
      if (data.status === 'success') {
        setUser(data.user.login);
        setUserId(data.user.rowid);
        setCompany(data.user.entity);
        setPwd(password);
       
        localStorage.setItem('user', data.user.login);
        localStorage.setItem('userId', data.user.rowid);
        localStorage.setItem('company', data.user.entity);
        localStorage.setItem('pwd', password);
        
        await fetchVariables(username, password);
       
        return { status: 'success' };
      } else {
        return { status: 'error', message: 'Invalid credentials' };
      }
    } catch (error) {
      console.error('Error during login:', error);
      return { status: 'error', message: 'Error connecting to the server' };
    }
  };

  const fetchVariables = async (username, password) => {
    try {
      const response = await fetch(`${API_URL}/conf.php?login=${username}&password=${password}`, {
        method: 'GET',
      });
      const data = await response.json();
      if (data.status === 'success') {
        const vars = {};
        data.variables.forEach((variable) => {
          vars[variable.name] = variable.value;
        });
        setVariables(vars);
        localStorage.setItem('variables', JSON.stringify(vars));
      } else {
        console.error("Error fetching variables:", data.message);
      }
    } catch (error) {
      console.error('Error fetching variables:', error);
    }
  };

  const logout = () => {
    setUser(null);
    setUserId(null);
    setCompany(null);
    setPwd(null);
    setVariables({});
    localStorage.removeItem('user');
    localStorage.removeItem('userId');
    localStorage.removeItem('company');
    localStorage.removeItem('pwd');
    localStorage.removeItem('variables');
  };

  return (
    <AuthContext.Provider value={{ pwd, user, company, userId, variables, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};